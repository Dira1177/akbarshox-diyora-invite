
import { useEffect, useState } from "react";

function Countdown({ targetDate }) {
  const [timeLeft, setTimeLeft] = useState({});

  useEffect(() => {
    const timer = setInterval(() => {
      const difference = +new Date(targetDate) - +new Date();
      const time = {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
      setTimeLeft(time);
    }, 1000);
    return () => clearInterval(timer);
  }, [targetDate]);

  return (
    <div className="flex justify-center gap-4 text-pink-800 text-xl font-semibold mt-4">
      {Object.entries(timeLeft).map(([unit, value]) => (
        <div key={unit}>
          {value} {unit}
        </div>
      ))}
    </div>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-cover bg-center text-center text-white p-6" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1525396528778-69b3d5e3f7d4?auto=format&fit=crop&w=1950&q=80')" }}>
      <iframe width="0" height="0" src="https://www.youtube.com/embed/pBa-9GJ-IXg?autoplay=1&loop=1&playlist=pBa-9GJ-IXg" allow="autoplay"></iframe>
      <h1 className="text-4xl md:text-6xl font-bold text-pink-100 drop-shadow-xl">Akbarshox & Diyora</h1>
      <p className="mt-4 text-xl md:text-2xl">Sizni bizning nikoh to‘yimizga taklif qilamiz</p>
      <p className="mt-2">📅 11-may 2025-yil | 📍 Qarshi shahar, Mo'jiza to'yxonasi</p>

      <Countdown targetDate="2025-05-11T18:00:00" />

      <div className="mt-8">
        <a href="https://maps.google.com" target="_blank" rel="noopener noreferrer">
          <button className="bg-pink-600 hover:bg-pink-700 text-white py-2 px-6 rounded-full shadow-lg">Lokatsiyani ko‘rish</button>
        </a>
      </div>

      <div className="mt-10 max-w-xl mx-auto text-pink-100">
        <p className="italic text-lg">"U zot sizlar uchun o‘zlaringizdan juftlar yaratib qo‘ydi va qalblaringizga mehr-oqibat soldi. Albatta, bunda tafakkur qiladiganlar uchun ibratlar bor."</p>
        <p className="mt-2 text-sm">(Rum surasi, 21-oyat)</p>
      </div>

      <form className="mt-12 max-w-md mx-auto bg-white bg-opacity-20 backdrop-blur p-6 rounded-lg shadow-lg">
        <h2 className="text-xl font-semibold mb-4">RSVP - Ishtirokni tasdiqlang</h2>
        <input type="text" placeholder="Ismingiz" className="w-full p-2 mb-2 rounded" />
        <input type="text" placeholder="Nechta mehmon bilan kelasiz?" className="w-full p-2 mb-2 rounded" />
        <button type="submit" className="bg-pink-600 hover:bg-pink-700 text-white py-2 px-4 rounded-full">Yuborish</button>
      </form>
    </div>
  );
}
